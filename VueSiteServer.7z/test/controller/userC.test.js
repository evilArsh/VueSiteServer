// 注册模块测试通过(--del 密码复杂度)
// 'use strict';
// const { app /* mock, assert*/ } = require('egg-mock/bootstrap');
// describe('test/controller/userC.test.js', () => {
//   describe('POST /api/user', () => {
//     it('should status 200 and get the body', () => {
//       // 对 app 发起 `POST /` 请求
//       // 模拟csrfToken
//       app.mockCsrf();
//       // const ctx = app.mockContext();
//       return app.httpRequest()
//         .post('/api/user')
//         .type('application/json')
//         .send({ userMail: '13521389587@qq.com', userPassword: 'test' })
//         .expect(200)
//         .expect('hello world');
//     });
//   });
// });
