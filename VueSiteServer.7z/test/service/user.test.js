// 注册service测试通过
// 'use strict';
// const { app /* mock*/, assert } = require('egg-mock/bootstrap');
// describe('test/service/user.test.js', () => {
//   it('test the register method', async () => {
//     app.mockCsrf();
//     const ctx = app.mockContext();
//     const user = await ctx.service.user.login({
//       userMail: '1183520543@qq.com',
//       userPassword: '123456789',
//     });
//     assert(JSON.stringify(user)==='foo');
//   });
// });
// 'use strict';
// const { app /* mock*/, assert } = require('egg-mock/bootstrap');
// describe('test/service/user.test.js', () => {
//   it('test the register method', async () => {
//     const ctx = app.mockContext();
//     const user = await ctx.service.user.login({
//       userMail: 'asdasdasdasdasd@qq.com',
//       userPassword: '123456789',
//     });
//     assert(user.success);
//   });
// });
